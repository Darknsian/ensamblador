import Titulo from'./Titulo';

function App() {
  return <Titulo/>;

}
export default App;