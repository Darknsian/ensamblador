function Titulo() {
    return (
      <div className="inicio">
        <h1>Manual de Ensamblador</h1>
        <p>Bienvenido al manual de programación en lenguaje ensamblador.</p>
        <p>Este manual está diseñado para ayudarte a aprender y entender los conceptos básicos y avanzados del ensamblador.</p>
        <h2>Contenido del Manual</h2>
        <ul>
          <li>Introducción al Ensamblador</li>
          <li>Registros y Modos de Direccionamiento</li>
          <li>Instrucciones Básicas</li>
          <li>Instrucciones de Control de Flujo</li>
          <li>Llamadas al Sistema y Interrupciones</li>
          <li>Optimización de Código</li>
          <li>Ejemplos Prácticos</li>
        </ul>
        <p>Selecciona un tema para comenzar.</p>
      </div>
    );
  }
  
  export default Titulo;